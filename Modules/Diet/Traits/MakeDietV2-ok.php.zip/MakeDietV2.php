<?php
namespace Modules\Diet\Traits;

use Carbon\Carbon;
use Modules\Diet\Entities\DietPlan;
use Modules\Diet\Entities\DietRequest;
use Modules\Diet\Entities\Food;
use Modules\Diet\Entities\Meal;

trait MakeDietV2
{
    public function makeDietFromFoods(DietRequest $dietRequest)
    {
        $totalCalories = $dietRequest->detail['caloriesAndUnits']['calorie'];

        $foodsGroupedByMeal = $this->getFoodsGroupedByMeal($dietRequest , $totalCalories);
        $selectedFoodsPerMeal = $this->initializeSelectedFoods($foodsGroupedByMeal);

        $days = $dietRequest->dietPlan->day_count;
        $result = [];

        for ($day = 1; $day <= $days; $day++) {
            $result[$day] = $this->generateDailyPlan($day, $dietRequest, $foodsGroupedByMeal, $selectedFoodsPerMeal);
        }


        $result = [
            'data' => [
                'calorieBreakdown' => [
                    'total' => $totalCalories, // کالری کل
                    'meals' => $this->calculateMealCalories($dietRequest->dietPlan, $totalCalories), // استفاده از تابع
                ],
            ],
            'result' => $result,
        ];

        $userDiet = $this->processFoodList($result);
        return $this->saveDietRequestDetailsWithSnapshot($dietRequest , $userDiet);
    }

    private function saveDietRequestDetailsWithSnapshot(DietRequest $dietRequest, array $processedData)
    {
        foreach ($processedData['result'] as $day => $meals) {
            foreach ($meals as $meal) {
                if ($meal['final_food_id'] != null && $meal['food_id'] != null) {
                    continue;
                }

                $food = Food::with('basicFoodPivot')->find($meal['final_food_id']);

                if (!$food) {
                    continue;
                }

                $basicFoods = $food->basicFoodPivot->map(function ($pivot) {
                    return [
                        'basic_food_id' => $pivot->id,
                        'name' => $pivot->name,
                        'quantity' => $pivot->pivot->quantity,
                        'unit' => $pivot->units()->where('is_primary', '1')->first()?->name ?? $pivot->units()->first()->name,
                    ];
                });

                $foodSnapshot = [
                    'food_id' => $food->id,
                    'food_name' => $food->name,
                    'basic_foods' => $basicFoods,
                ];

                $dietRequestDetailData = [
                    'diet_request_id' => $dietRequest->id,
                    'meal_id' => $meal['meal_id'],
                    'carb' => $food->carb,
                    'protein' => $food->protein,
                    'fat' => $food->fat,
                    'fiber' => $food->fiber,
                    'calories' => $meal['final_calories'],
                    'day_number' => $day,
                    'date_of_day' => Carbon::now()->addDays($day)->toDateString(),
                    'detail' => json_encode(formatDecimalArray([
                        'calorie_difference' => $meal['calorie_difference'],
                        'food_snapshot' => $foodSnapshot,
                    ]), JSON_UNESCAPED_UNICODE),

                ];

                $food = Food::find($meal['food_id'])->dietRequestDetails()->create($dietRequestDetailData);
            }
        }
        return true;
    }
    private function calculateMealCalories($dietPlan, $totalCalories)
    {
        $mealCalorieDetails = [];

        foreach ($dietPlan->meals as $meal) {
            $mealCalories = round($totalCalories * ($meal->pivot->calorie_percent / 100), 1);

            $mealCalorieDetails[] = [
                'meal_id' => $meal->id,
                'meal_name' => $meal->name,
                'calories' => $mealCalories, // کالری مورد نیاز برای این وعده
            ];
        }

        return $mealCalorieDetails;
    }

    private function haveSpecialMeal(DietRequest $dietRequest, $mealId): bool
    {
        if (array_key_exists($mealId, $dietRequest->dietPlan->detail[DietPlan::DETAIL_SPECIAL_BASIC_FOODS])) {
            return true;
        }
        return false;
    }
    private function getFoodsGroupedByMeal(DietRequest $dietRequest, $totalCalories)
    {
        $conditions = $dietRequest->detail['condition'] ?? app('dietService')->getUserConditions($dietRequest->user);
        unset($conditions[3]);

        $mealCaloriesDetails = $this->calculateMealCalories($dietRequest->dietPlan, $totalCalories); // فراخوانی تابع
        $foodsGroupedByMeal = [];

        foreach ($mealCaloriesDetails as $mealDetails) {
            $mealId = $mealDetails['meal_id'];
            $mealCalories = $mealDetails['calories'];

            // when have special food
            if (self::haveSpecialMeal($dietRequest, $mealId)) {
                $specialMealsId = $dietRequest->dietPlan->detail[DietPlan::DETAIL_SPECIAL_BASIC_FOODS][$mealId];
                $filteredFoods = Food::whereIn('id', $specialMealsId);
            } else {
                $listFoods = self::getFoods($conditions, $mealId);
                $filteredFoods = $listFoods->filter(function ($food) use ($mealCalories) {
                    return $food->calories <= $mealCalories && $food->max_calories >= $mealCalories;
                });
            }


            $foodsGroupedByMeal[$mealId] = $filteredFoods->pluck('id')->toArray();
        }

        return $foodsGroupedByMeal;
    }

    private function initializeSelectedFoods($foodsGroupedByMeal)
    {
        $selectedFoodsPerMeal = [];
        foreach ($foodsGroupedByMeal as $mealId => $foods) {
            $selectedFoodsPerMeal[$mealId] = $foods;
        }

        return $selectedFoodsPerMeal;
    }

    public function processFoodList(array $data)
    {
        $calorieBreakdown = $data['data']['calorieBreakdown']; // کالری‌های مورد نیاز
        $result = $data['result']; // لیست وعده‌ها
        $updatedResult = []; // لیست نهایی

        foreach ($result as $day => $meals) {
            $currentCalorieOffset = 0; // اختلاف کالری جاری برای هر روز

            foreach ($meals as &$meal) {
                $mealId = $meal['meal_id'];
                $parentId = $meal['food_id'];

                $closestFood = null;
                if ($parentId) {
                    // یافتن کالری مورد نیاز برای این وعده
                    $requiredCalories = collect($calorieBreakdown['meals'])->firstWhere('meal_id', $mealId)['calories'] ?? 0;

                    // اعمال اختلاف کالری
                    $adjustedCalories = $requiredCalories + $currentCalorieOffset;

                    // پیدا کردن نزدیک‌ترین غذا
                    $relatedFoods = Food::where('parent_id', $parentId)->get();

                    $closestFood = $relatedFoods->reduce(function ($closest, $food) use ($adjustedCalories) {
                        $currentDifference = abs($food->calories - $adjustedCalories);

                        if (!$closest || $currentDifference < abs($closest->calories - $adjustedCalories)) {
                            return $food; // غذای جدید نزدیک‌تر است
                        }

                        return $closest;
                    });
                }

                if ($closestFood) {
                    // محاسبه اختلاف کالری
                    $calorieDifference = $closestFood->calories - $adjustedCalories;

                    // افزودن اطلاعات به وعده
                    $meal['final_food_id'] = $closestFood->id;
//                    $meal['final_food_name'] = $closestFood->name;
                    $meal['final_calories'] = $closestFood->calories;
                    $meal['calorie_difference'] = $calorieDifference;
                    $meal['adjusted_calories'] = $adjustedCalories;

                    // به‌روزرسانی اختلاف کالری برای وعده بعدی
                    $currentCalorieOffset = $calorieDifference;
                } else {
                    // اگر هیچ غذای مناسب پیدا نشد
                    $meal['final_food_id'] = null;
                    $meal['final_food_name'] = 'Not Found';
                    $meal['final_calories'] = 0;
                    $meal['calorie_difference'] = 0;
                    $currentCalorieOffset = 0; // عدم اعمال اختلاف برای وعده بعدی
                }
            }

            $updatedResult[$day] = $meals; // ذخیره وعده‌های به‌روزرسانی‌شده
        }

        return [
            'data' => $data['data'],
            'result' => $updatedResult
        ];
    }
    private function calculateDailyCalories(array $data)
    {
        $result = $data['result']; // لیست وعده‌ها
        $updatedResult = []; // لیست نهایی با جمع کالری هر روز

        foreach ($result as $day => $meals) {
            $dailyCalories = 0;

            // محاسبه مجموع کالری هر روز
            foreach ($meals as $meal) {
                $dailyCalories += $meal['final_calories'] ?? 0;
            }

            // اضافه کردن ردیف نتیجه
            $meals[] = [
                'meal' => 'نتیجه',
                'meal_id' => null,
                'food_id' => null,
                'day' => $day,
                'final_food_id' => null,
                'final_food_name' => 'جمع کل کالری',
                'final_calories' => $dailyCalories,
                'calorie_difference' => null,
            ];

            $updatedResult[$day] = $meals;
        }

        // بازگشت داده‌ها
        return [
            'data' => $data['data'],
            'result' => $updatedResult,
        ];
    }
    private function generateDailyPlan($day, DietRequest $dietRequest, &$foodsGroupedByMeal, &$selectedFoodsPerMeal)
    {
        $meals = $dietRequest->dietPlan->meals()->orderBy('priority')->get();
        $usedFoodsToday = [];
        $dailyPlan = [];

        foreach ($meals as $meal) {
            $mealId = $meal->id;

            // اگر لیست خالی است، آن را ریست کنید
            if (empty($selectedFoodsPerMeal[$mealId])) {
                $selectedFoodsPerMeal[$mealId] = $foodsGroupedByMeal[$mealId];
            }

            // انتخاب غذا از لیست موجود
            $availableFoods = array_diff($selectedFoodsPerMeal[$mealId], $usedFoodsToday);
            if (empty($availableFoods)) {
                // ریست کردن لیست اگر تمام غذاها استفاده شده باشند
                $selectedFoodsPerMeal[$mealId] = $foodsGroupedByMeal[$mealId];
                $availableFoods = array_diff($selectedFoodsPerMeal[$mealId], $usedFoodsToday);
            }

            // انتخاب غذا
            $selectedFood = array_shift($availableFoods);

            // حذف غذا از لیست
            $selectedFoodsPerMeal[$mealId] = array_diff($selectedFoodsPerMeal[$mealId], [$selectedFood]);

            // ذخیره اطلاعات روزانه
            $usedFoodsToday[] = $selectedFood;
            $dailyPlan[] = [
                'meal' => $meal->name,
                'meal_id' => $meal->id,
                'food_id' => $selectedFood,
                'availableFoods' => $availableFoods,
                'day' => $day,
            ];
        }

        return $dailyPlan;
    }
}
